﻿Public Class Prog1

    Public Shared Sub Main()
        Application.Run(New FormClassCreate)
    End Sub

End Class